﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Manager : MonoBehaviour
{
    public GameObject GameButten;
    public GameObject Title;
    public GameObject CreditImage;
    public GameObject SoundOffImage;

    public void Awake()
    {
        if (PlayerPrefs.HasKey("Sound") == false)
        {
            PlayerPrefs.SetInt("Sound", 1);
            SoundOffImage.SetActive(false);
        }
    }
    public void GameStart()
    {
        SceneManager.LoadScene(1);
    }
    public void Credit()
    {
        GameButten.SetActive(!GameButten.activeSelf);
        Title.SetActive(!Title.activeSelf);
        CreditImage.SetActive(!CreditImage.activeSelf);
    }
    public void Sound()
    {
        SoundOffImage.SetActive(!SoundOffImage.activeSelf);
        if (SoundOffImage.activeSelf)
            PlayerPrefs.SetInt("Sound", 0);
        else
            PlayerPrefs.SetInt("Sound", 1);
    }
}
