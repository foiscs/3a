﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class RandomBG : MonoBehaviour
{
    public List<Sprite> BackGround = new List<Sprite>();
    private void Awake()
    {
        this.GetComponent<Image>().sprite = BackGround[Random.Range(0, 3)];
    }
}
