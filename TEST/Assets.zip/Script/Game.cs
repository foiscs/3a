﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class Game : MonoBehaviour
{
    public static int gridWidth = 5;
    public static int gridHeight = 5;
    private Touch initTouch = new Touch();
    int ComboCount = 0;
    float ComboTime = 0;
    public float ComboKeepTime = 20;

    public Button B_Speed;
    public float[] DownSpeedList = { 1f, 1.5f, 2f };
    public int DownSpeed = 0;


    public Button B_Up;
    public Button B_Down;
    public Button B_Left;
    public Button B_Right;
    
    public Button B_Rotation;

    [SerializeField]
    private int Score = 0;
    public Text T_Score;
    private int TopScore;
    public Text T_TopScore;
    
    private int EnterCount;
    private List<GameObject> EnterObject = new List<GameObject>();

    public List<GameObject> Block = new List<GameObject>();
    public GameObject pickUpBlock = null;


    private void Awake()
    {
        if (PlayerPrefs.HasKey("TopScore") == false)
            TopScore = 0;
        else
            TopScore = PlayerPrefs.GetInt("TopScore");

        T_TopScore.text = "<b>TopScore : </b>" + "<b>" + TopScore + "</b>";
    }
    void Start()
    {
        pickUpBlock = Instantiate(Block[Random.Range(0, 5)],this.transform.GetChild(1));
        pickUpBlock.transform.position = new Vector3(0, 70, 0);
        pickUpBlock.transform.eulerAngles = new Vector3(0, 45, 0);
    }

    // Update is called once per frame
    void Update()
    {
        CheckComboTime();
        RandomBlockPickUp();
        //20초동안 한줄 안터지면 콤보수 초기화 
    }
    public bool CheckIsInsideGrid(Vector3 pos)
    {
        return ((int)pos.x >= 0 && (int)pos.x < gridWidth && (int)pos.z >= 0);
    }
    public Vector3 Round(Vector3  pos)
    {
        return new Vector3(Mathf.Round(pos.x), Mathf.Round(pos.z));
    }

    public void RandomBlockPickUp()
    {
        if (pickUpBlock.GetComponent<Tetromino>().enabled == false)
        {
            pickUpBlock = Instantiate(Block[Random.Range(0, 5)], this.transform.GetChild(1));
            pickUpBlock.transform.position = new Vector3(0, 70, 0);
            pickUpBlock.transform.eulerAngles = new Vector3(0, 45, 0);

            pickUpBlock.GetComponent<Tetromino>().fallSpeed = DownSpeedList[DownSpeed];
        }
    }
    public void PlusDownSpeed()
    {
        DownSpeed++;
        if (DownSpeed > 2)
            DownSpeed = 0;
        pickUpBlock.GetComponent<Tetromino>().fallSpeed = DownSpeedList[DownSpeed];
    }

    //BLOCK MOVIONG
    public void Move_B_Up()
    {
        pickUpBlock.transform.localPosition += new Vector3(0, 0, 1.4f);
    }
    public void Move_B_Down()
    {
        pickUpBlock.transform.localPosition += new Vector3(0, 0, -1.4f);
    }
    public void Move_B_Left()
    {
        pickUpBlock.transform.localPosition += new Vector3(-1.4f, 0, 0);
    }
    public void Move_B_Right()
    {
        pickUpBlock.transform.localPosition += new Vector3(1.4f, 0, 0);
    }

    public void Move_B_Rotation()
    {
        pickUpBlock.transform.eulerAngles += new Vector3(0, 90, 0);
    }
    private void CheckComboTime()
    {
        if (Time.time - ComboTime >= ComboKeepTime)
        {
            ComboCount = 0;
        }
    }
    private void PlusScore()
    {
        if (ComboCount != 0)
            Score += 150;
        else
        {
            Score = 100;
            ComboCount = 1;
            ComboKeepTime = Time.time;
        }
        T_Score.text = "<b>Score : </b>" + "<b>" + Score + "</b>";
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.tag == "Box")
        {
            EnterCount++;
            EnterObject.Add(other.gameObject);
        }

        if (EnterCount == 49)
        {
            EnterCount = 0;
            PlusScore();

            for (int i = 0; i < 49; i++)
            {
                Destroy(EnterObject[0]);
            }
        }
    }
}
