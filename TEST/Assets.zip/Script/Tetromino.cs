﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class Tetromino : MonoBehaviour
{

    float fall = 0;
    public float fallSpeed = 1;
    int layerMask = 1 << 8;

    private void Start()
    {
        
    }
    private void Update()
    {

        RaycastHit hit;
        for (int i = 0; i < transform.childCount; i++)
        {
            GameObject child = transform.GetChild(i).gameObject;
            if (Physics.Raycast(child.transform.position, child.transform.TransformDirection(Vector3.back), out hit, Mathf.Infinity, layerMask))
            {
                Debug.DrawRay(child.transform.position, child.transform.TransformDirection(Vector3.back) *10, Color.yellow);
                if(transform.name != hit.transform.parent.name && (child.transform.position.y - hit.transform.position.y)<8)
                {
                    this.GetComponent<Tetromino>().enabled = false;
                }
            }
            else
            {
                Debug.DrawRay(child.transform.position, child.transform.TransformDirection(Vector3.back) * 1000, Color.white);
                Debug.Log("Did not Hit");
            }
        }
        CheckUserInput();

    }
    private void CheckUserInput()
    {
       if(Time.time - fall >= fallSpeed)
        {
            if (transform.position.y > 0)
            {
                transform.position += new Vector3(0, -7, 0);
            }
            else
            {
                transform.position += new Vector3(0, 0, 0);
                this.GetComponent<Tetromino>().enabled = false;
            }
            fall = Time.time;

        }
    }
    bool CheckIsValidPosition()
    {
        foreach (Transform mino in transform)
        {
            Vector3 pos = FindObjectOfType<Game>().Round(mino.position);

            if (FindObjectOfType<Game>().CheckIsInsideGrid(pos) == false)
            {
                return false;
            }
        }
        return true;
    }
}
