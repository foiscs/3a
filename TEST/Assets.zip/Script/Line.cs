﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Line : MonoBehaviour
{
    BoxCollider box;

    public GameObject parent;
    public List<GameObject> block; 
    void Start()
    {
        parent = transform.parent.parent.GetChild(1).gameObject;
        box = GetComponent<BoxCollider>();
    }

    void Update()
    {
        
    }
    void deleteBlock()
    {
        if (block.Count >= 49)
        {
            for (int i = 0; i < block.Count; i++)
            {
                Destroy(block[i]);
            }
            block.Clear();

            for (int i = 0; i < parent.transform.childCount; i++)
            {
                for (int j = 0; j < parent.transform.GetChild(i).childCount; j++)
                {
                    Vector3 ve= parent.transform.GetChild(i).GetChild(j).position;
                    ve.y -= 7;
                    if(parent.transform.GetChild(i).GetChild(j).position.y > transform.position.y)
                        parent.transform.GetChild(i).GetChild(j).position = ve;
                }
            }

        }
    }
    private void OnTriggerStay(Collider other)
    {
        if(!other.name.Contains("qube"))
        {
            return;
        }
        for(int i = 0; i < block.Count; i++)
        {
            if(other.gameObject == block[i])
            {
                return;
            }
        }
        Tetromino te = other.gameObject.GetComponentInParent<Tetromino>();
        if(!te.enabled)
            block.Add(other.gameObject);
        deleteBlock();
    }
    private void OnTriggerExit(Collider other)
    {
        for(int i = 0; i < block.Count; i++)
        {
            if(block[i] == other.gameObject)
            {
                block.Remove(block[i]);
                break;
            }
        }
    }
}
